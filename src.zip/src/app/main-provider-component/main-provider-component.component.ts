import { Component } from '@angular/core';

@Component({
  selector: 'app-main-provider-component',
  templateUrl: './main-provider-component.component.html',
  styleUrls: ['./main-provider-component.component.css']
})
export class MainProviderComponentComponent {

}
