export class Fournisseur
{
    idFournisseur! : number;
    code! : string;
    libelle! : string;
}