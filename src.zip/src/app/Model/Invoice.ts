export class Invoice{
    idFacture!:number;
    montantFacture!:number;
    montantRemise!:number;
    dateFacture!:string;
    active!:boolean;
    }