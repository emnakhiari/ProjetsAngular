export class Produit {
    idProduit! : number;
    code!:string;
    libelle!:string;
    prixUnitaire!:number;
    tauxTVA!:number;
    }