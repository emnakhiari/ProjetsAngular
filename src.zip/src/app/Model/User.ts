export class User
{
    image? :string ; 
    typeAccount? : string ; 
    description? : string ; 
    
}