import { Component } from '@angular/core';

@Component({
  selector: 'app-not-found-page-component',
  templateUrl: './not-found-page-component.component.html',
  styleUrls: ['./not-found-page-component.component.css']
})
export class NotFoundPageComponentComponent {

}
