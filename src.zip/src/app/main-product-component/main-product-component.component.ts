import { Component } from '@angular/core';

@Component({
  selector: 'app-main-product-component',
  templateUrl: './main-product-component.component.html',
  styleUrls: ['./main-product-component.component.css']
})
export class MainProductComponentComponent {

}
